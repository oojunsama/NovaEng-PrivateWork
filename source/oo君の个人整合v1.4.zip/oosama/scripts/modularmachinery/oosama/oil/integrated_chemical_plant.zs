//石化配方
#priority 10
#loader crafttweaker reloadable

import mods.modularmachinery.RecipePrimer;
import mods.modularmachinery.RecipeBuilder;
import mods.modularmachinery.IngredientArrayBuilder;
import mods.modularmachinery.MachineModifier;
import mods.modularmachinery.MachineBuilder;
import mods.modularmachinery.RecipeModifierBuilder;
import mods.modularmachinery.RecipeAdapterBuilder;
import mods.modularmachinery.MultiblockModifierBuilder;
import mods.modularmachinery.BlockArrayBuilder;

import mods.modularmachinery.FactoryRecipeTickEvent;
import mods.modularmachinery.RecipeTickEvent;
import mods.modularmachinery.Sync;

import crafttweaker.world.IBlockPos;
import crafttweaker.world.IWorld;
import crafttweaker.item.IItemStack;
import crafttweaker.data.IData;
import crafttweaker.item.IIngredient;
import crafttweaker.oredict.IOreDictEntry;
import crafttweaker.liquid.ILiquidStack;
import crafttweaker.item.WeightedItemStack;
import mod.mekanism.gas.IGasStack;
import mods.astralsorcery.Altar;
import crafttweaker.item.IWeightedIngredient;

import novaeng.hypernet.HyperNetHelper;




//内置并行设置
MachineModifier.setInternalParallelism("integrated_chemical_plant", 16);

//工厂线程设置
MachineModifier.setMaxThreads("integrated_chemical_plant", 8);

//最大并行数 512
MachineModifier.setMaxParallelism("integrated_chemical_plant", 512);

//扭集成控制器
RecipeBuilder.newBuilder("integrated_chemical_plant_controller", "machine_arm", 1800)
    .addEnergyPerTickInput(96000)
    .addInputs([
        <contenttweaker:industrial_circuit_v3> * 8,
        <contenttweaker:electric_motor_v3> * 8,
        <contenttweaker:sensor_v3> * 16,
        <modularmachinery:chemical_complex_controller> * 2,
        <modularmachinery:blockcasing:4>,
    ])
    .addOutput(<modularmachinery:integrated_chemical_plant_factory_controller>)
    .build();

//扭配方继承虽然来说似乎都没有用的
RecipeAdapterBuilder.create("integrated_chemical_plant", "nuclearcraft:chemical_reactor")
    .addModifier(RecipeModifierBuilder.create("modularmachinery:duration", "input", 0.025, 1, false).build())
    .addModifier(RecipeModifierBuilder.create("modularmachinery:energy",   "input", 4000, 1, false).build())
    .build();


//硫酸3.0
    RecipeBuilder.newBuilder("liusuan30", "integrated_chemical_plant",480,0)
        .addEnergyPerTickInput(3200000)
        .addCatalystInput(<avaritia:resource:5>,
        ["催化配方以2倍速度运行"],
        [RecipeModifierBuilder.create("modularmachinery:duration", "input", 0.5F, 1, false).build()]).setChance(0).setParallelizeUnaffected(true)
        .addInput(<extendedcrafting:material:11>).setPreViewNBT({display: {Lore: ["§a数量决定并行"]}}).setChance(0).setParallelizeUnaffected(true)
        .addInputs([
            <ore:dustSulphur> * 32,
            <liquid:oxygen> * 48000,
            <liquid:water> * 32000,])
        .addOutput(<liquid:sulfuric_acid> * 32000)
    .build();

//碳纳米管 集成 替代 上位
RecipeBuilder.newBuilder("carbon_nanotube", "integrated_chemical_plant", 80)
    .addEnergyPerTickInput(40000)
    .addInputs(<contenttweaker:graphene> * 2)
    .addInput(<mets:niobium_titanium_plate> * 1).setChance(0)
    .addOutputs(<contenttweaker:carbon_nanotube> * 1)
    .build();

//生产营养精华液-普通配方
RecipeBuilder.newBuilder("nutrient_distillation_0", "integrated_chemical_plant", 200)
    .addEnergyPerTickInput(28800)
    .addFluidInputs(<liquid:water> * 4000)
    .addIngredientArrayInput(
     IngredientArrayBuilder.newBuilder()
        .addIngredients([
            <minecraft:skull>,  
            <minecraft:skull:1>, 
            <minecraft:skull:2>,  
            <minecraft:skull:4>,  
            <enderio:block_enderman_skull>,  
        ])
    .build()
)
    .addIngredientArrayInput(
     IngredientArrayBuilder.newBuilder()
        .addIngredients([
            <minecraft:nether_wart>, 
            <minecraft:brown_mushroom>, 
            <minecraft:red_mushroom>,  
        ])
    .build()
)
    .addFluidOutput(<liquid:nutrient_distillation>* 1000)
    .build();

//生产营养精华液-低级配方
RecipeBuilder.newBuilder("nutrient_distillation_1", "integrated_chemical_plant", 200)
    .addEnergyPerTickInput(28800)
    .addFluidInputs(<liquid:water> * 4000)
    .addIngredientArrayInput(
     IngredientArrayBuilder.newBuilder()
        .addIngredients([
            <minecraft:skull>, 
            <minecraft:skull:1>,
            <minecraft:skull:2>,
            <minecraft:skull:4>,
            <enderio:block_enderman_skull>,
        ])
    .build()
)
   .addInputs( <minecraft:sugar>)
    .addFluidOutput(<liquid:nutrient_distillation> * 500)
    .build();

//生产营养精华液-高级配方
RecipeBuilder.newBuilder("nutrient_distillation_2", "integrated_chemical_plant", 200)
    .addEnergyPerTickInput(28800)
    .addFluidInputs(<liquid:water> * 4000)
    .addIngredientArrayInput(
     IngredientArrayBuilder.newBuilder()
        .addIngredients([
            <minecraft:skull>,
            <minecraft:skull:1>,
            <minecraft:skull:2>,
            <minecraft:skull:4>,
            <enderio:block_enderman_skull>,
        ])
    .build()
)
    .addInputs([<minecraft:fermented_spider_eye>])
    .addFluidOutput(<liquid:nutrient_distillation> * 1500)
    .build();
    
//营养糊剂生产营养精华液-顶级配方
RecipeBuilder.newBuilder("nutrient_distillation_3","integrated_chemical_plant", 200)
    .addEnergyPerTickInput(28800)
    .addFluidInputs(<liquid:water> * 4000) 
    .addInputs(<minecraft:skull:5>)
    .addInputs(<minecraft:fermented_spider_eye>)
    .addFluidOutput(<liquid:nutrient_distillation> * 2000) 
    .build();

//扭冷却液
RecipeBuilder.newBuilder("lengqueyan_niu","integrated_chemical_plant",10)
   .addEnergyPerTickInput(54000)
   .addInputs(<ic2:dust:9>*9)
   .addFluidInputs(<liquid:water>* 1000) 
   .addFluidOutput(<liquid:ic2coolant> * 1000)
    .build();

    //扭DT燃料的D
RecipeBuilder.newBuilder("mekdtranliaoded_niu", "integrated_chemical_plant", 10)
    .addEnergyPerTickInput(1024000)
    .addFluidInputs(<liquid:heavywater>* 1000) 
    .addFluidOutput(<liquid:deuterium>* 1000)
    .build();

    //扭DT燃料的T
RecipeBuilder.newBuilder("mekdtranliaodet_niu", "integrated_chemical_plant", 10)
    .addEnergyPerTickInput(1024000)
    .addFluidInputs(<liquid:liquidlithium>* 1000) 
    .addFluidOutput(<liquid:tritium>* 1000)
    .build();

    //扭红石水晶
RecipeBuilder.newBuilder("hongshishuijing_niu", "integrated_chemical_plant", 10)
    .addEnergyPerTickInput(1024000)
    .addInputs(<minecraft:diamond>) 
    .addFluidInputs(<liquid:redstone>* 500) 
    .addOutputs(<redstonearsenal:material:160>)
    .build();

    //扭极寒水晶
RecipeBuilder.newBuilder("jihanshuijing_niu", "integrated_chemical_plant", 10)
    .addEnergyPerTickInput(1024000)
    .addInputs(<minecraft:emerald>) 
    .addFluidInputs(<liquid:cryotheum>* 1000) 
    .addOutputs(<redstonerepository:material:5>)
    .build();

    //扭极寒末影锭
RecipeBuilder.newBuilder("jihanmoyinding_niu", "integrated_chemical_plant", 10)
    .addEnergyPerTickInput(1024000)
    .addInputs(<thermalfoundation:material:167>) 
    .addFluidInputs(<liquid:cryotheum>* 1000) 
    .addOutputs(<redstonerepository:material:1>)
    .build();

    //原油裂解成4个
RecipeBuilder.newBuilder("oil_liejie", "integrated_chemical_plant", 800)
    .addEnergyPerTickInput(40000)
    .addFluidInputs(<liquid:oil>*1000)
    .addFluidOutput(<liquid:oil_sulfur_rich_refinery_gas>*250)
    .addFluidOutput(<liquid:oil_sulfur_rich_light_fuel>*250)
    .addFluidOutput(<liquid:oil_sulfur_rich_heavy_fuel>*250)
    .addFluidOutput(<liquid:refined_oil>*250)
    .build();

    //含硫轻燃油+氢气=硫化氢+轻燃油
RecipeBuilder.newBuilder("oil_hlqrycl", "integrated_chemical_plant", 800)
    .addEnergyPerTickInput(40000)
    .addFluidInputs([
        <liquid:oil_sulfur_rich_light_fuel>*1000,
        <liquid:ic2hydrogen>*1000
    ])
    .addFluidOutput(<liquid:oil_light_fuel>*1000)
    .addFluidOutput(<liquid:oil_h2s>*1000)
    .build();

    //硫化氢+水=硫酸
RecipeBuilder.newBuilder("oil_lhqcl", "integrated_chemical_plant", 800)
    .addEnergyPerTickInput(40000)
    .addFluidInputs([
        <liquid:oil_h2s>*1000,
        <liquid:water>*1000
    ])
    .addFluidOutput(<liquid:sulfuric_acid>*1000)
    .build();

    //轻燃油+重燃油=燃油
RecipeBuilder.newBuilder("oil_ryhc", "integrated_chemical_plant", 800)
    .addEnergyPerTickInput(40000)
    .addFluidInputs([
        <liquid:oil_light_fuel>*1000,
        <liquid:oil_heavy_fuel>*1000
    ])
    .addFluidOutput(<liquid:oil_fuel>*1000)
    .build();

    //含硫重燃油+氢气=硫化氢+重燃油
RecipeBuilder.newBuilder("oil_hlzrycl", "integrated_chemical_plant", 800)
    .addEnergyPerTickInput(40000)
    .addFluidInputs([
        <liquid:oil_sulfur_rich_heavy_fuel>*1000,
        <liquid:ic2hydrogen>*1000
    ])
    .addFluidOutput(<liquid:oil_heavy_fuel>*1000)
    .addFluidOutput(<liquid:oil_h2s>*1000)
    .build();


    //燃油+四硝基甲烷=高十六烷值柴油
RecipeBuilder.newBuilder("oil_gaoshiliusc", "integrated_chemical_plant", 800)
    .addEnergyPerTickInput(40000)
    .addFluidInputs([
        <liquid:oil_fuel>*1000,
        <liquid:oil_tetranitromethane>*1000
    ])
    .addFluidOutput(<liquid:oil_cetan_eboosted_diesel>*1000)
    .build();

      //乙烯酮+硝酸=四硝基甲烷
RecipeBuilder.newBuilder("oil_sxjjwcl", "integrated_chemical_plant", 800)
    .addEnergyPerTickInput(40000)
    .addFluidInputs([
        <liquid:oil_c2h2o>*1000,
        <liquid:oil_hno3>*1000
    ])  
    .addFluidOutput(<liquid:oil_tetranitromethane>*1000)
    .build();
  
    //水+氧气+硝石=硝酸
RecipeBuilder.newBuilder("oil_xssc", "integrated_chemical_plant", 800)
    .addEnergyPerTickInput(40000)
    .addInputs(<thermalfoundation:material:772>*9)
    .addFluidInputs([
        <liquid:ic2oxygen>*1000,
        <liquid:water>*1000
    ])
    .addFluidOutput(<liquid:oil_hno3>*1000)
    .build();

    //乙酸+硫酸=乙酸酮
RecipeBuilder.newBuilder("oil_yxtsc", "integrated_chemical_plant", 800)
    .addEnergyPerTickInput(40000)
    .addFluidInputs([
        <liquid:oil_c2h4o2>*1000,
        <liquid:sulfuric_acid>*1000
    ])
    .addFluidOutput(<liquid:oil_c2h2o>*1000)
    .build();

    //乙烯+氧气=乙酸
RecipeBuilder.newBuilder("oil_yssc333", "integrated_chemical_plant", 800)
    .addEnergyPerTickInput(40000)
    .addFluidInputs([
        <liquid:ethene>*1000,
        <liquid:ic2oxygen>*1000
    ])
    .addFluidOutput(<liquid:oil_c2h4o2>*1000)
    .build();

    //高十六燃烧
RecipeBuilder.newBuilder("16oil", "biogas_generator", 1551)
    .addFluidInputs(<liquid:oil_cetan_eboosted_diesel>*520)
    .addEnergyPerTickOutput(1145141919)
    .build();

    //燃油燃烧
RecipeBuilder.newBuilder("chaiyours", "biogas_generator", 1551)
    .addFluidInputs(<liquid:oil_fuel>*520)
    .addEnergyPerTickOutput(114514)
    .build();